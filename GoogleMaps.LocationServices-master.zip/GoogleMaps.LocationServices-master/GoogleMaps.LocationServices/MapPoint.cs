﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GoogleMaps.LocationServices
{
    public class MapPoint
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
