﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GoogleMaps.LocationServices
{
    public class Step
    {
        public string Instruction { get; set; }

        public string Distance { get; set; }
    }
}
